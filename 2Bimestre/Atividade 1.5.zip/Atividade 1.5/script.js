let valor1 = document.querySelector("#valor1");
let valor2 = document.querySelector("#valor2");
let btMaiorentre = document.querySelector("#btMaiorentre");
let h3Resultado = document.querySelector("#h3Resultado");

function verificacaovalor(){
    let num1 = Number(valor1.value);
    let num2 = Number(valor2.value);

    if(num1 > num2){

        h3Resultado.textContent = num1;
    }else{

        h3Resultado.textContent = num2;
    }
}
btMaiorentre.onclick = function(){
    verificacaovalor();
}