let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let Valor3 = document.querySelector("#Valor3");
let Valor4 = document.querySelector("#Valor4");
let btMostar = document.querySelector("#btMostar")
let resultado = document.querySelector("#resultado")

function valores(){

    let num1 = Number(Valor1.value);
    let num2 = Number(Valor2.value);
    let num3 = Number(Valor3.value);
    let num4 = Number(Valor4.value);

    if(num1 < num2 && num1 < num3 && num1 < num4){
        resultado.textContent = "O valor menor é o Primeiro"
    }else if(num2 < num1 && num2 < num3 && num2 < num4){
        resultado.textContent = "O valor menor é o Segundo"
    }else if(num3 < num1 && num3 < num2 && num3 <num4){
        resultado.textContent = "O valor menor é o Terceiro"
    }else if(num4 < num1 && num4 < num2 && num4 < num3){
        resultado.textContent = "O valor menor é o Quarto"
    }
}

btMostar.onclick = function(){
    valores();
}
