let Valor1 = document.querySelector("#Valor1");
let btVerificar = document.querySelector("#btVerificar");
let h3Resultado = document.querySelector("#h3Resultado")


function imparOUpar(){
    let num1 = (Valor1.value);


    // num1 % 2 Calcula o resto da divisão do número por 2.
    // !== 0 Verifica se o resto é diferente de 0. Se for diferente de 0,
    // significa que o número não é divisível por 2 e, portanto, é ímpar.
    if(num1 % 2 !== 0){
        h3Resultado.textContent = "É impar"
    }else{
        h3Resultado.textContent = "É par"
    }
}

btVerificar.onclick = function(){
    imparOUpar();
}