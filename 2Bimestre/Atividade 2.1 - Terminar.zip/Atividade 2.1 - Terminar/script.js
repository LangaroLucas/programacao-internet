let valor = document.querySelector("#valor");
let btResultado1 = document.querySelector("#btResultado1");
let btResultado2 = document.querySelector("#btResultado2");
let btResultado5 = document.querySelector("#btResultado5");
let btResultado10 = document.querySelector("#btResultado10");
let h3exibir = document.querySelector("#h3exibir");

function calcularPorcentagem(){

}