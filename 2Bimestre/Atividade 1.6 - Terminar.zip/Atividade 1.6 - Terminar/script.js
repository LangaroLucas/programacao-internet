let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let Valor3 = document.querySelector("#Valor3");
let Valor4 = document.querySelector("#Valor4");
let btMostar = document.querySelector("#btMostar")

function valores(){

    let num1 = Number(Valor1.value);
    let num2 = Number(Valor2.value);
    let num3 = Number(Valor3.value);
    let num4 = Number(Valor4.value);

    if(){

    }else{

    }
}

btMostar.onclick = function(){
    valores();
}
