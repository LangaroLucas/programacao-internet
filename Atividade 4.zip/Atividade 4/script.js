let Valor1 = document.querySelector("#Valor1");
let Valor2 = document.querySelector("#Valor2");
let Valor3 = document.querySelector("#Valor3");
let MediaAri = document.querySelector("#MediaAri");
let MediaPon = document.querySelector("#MediaPon");
let SomaMedias = document.querySelector("#SomaMedias");
let MediaMedias = document.querySelector("#MediaMedias")
let BtCalcular = document.querySelector("#BtCalcular");
let mediatotalPon;
let mediatotalAri;
let SomaTotal;

function Aritimetica(){
    mediatotalAri = ((Number(Valor1.value) + Number(Valor2.value) + Number(Valor3.value))/3);

    MediaAri.textContent = (mediatotalAri)
}

function Ponderada(){
    mediatotalPon = (((Number(Valor1.value) * 3) + (Number(Valor2.value) * 2) + (Number(Valor3.value) * 5))/10);

    MediaPon.textContent = (mediatotalPon)
}

function Soma(){
    SomaTotal = (mediatotalAri + mediatotalPon);

    SomaMedias.textContent = (SomaTotal)
}

function Media(){
    MediaTotal = ((mediatotalAri + mediatotalPon + SomaTotal)/3);

    MediaMedias.textContent = (MediaTotal)
}

BtCalcular.onclick = function(){
    Aritimetica();
    Ponderada();
    Soma();
    Media();
}

