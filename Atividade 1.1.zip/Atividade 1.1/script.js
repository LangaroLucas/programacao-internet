let inputNum1 = document.querySelector("#inputNum1")
let inputNum2 = document.querySelector("#inputNum2")
let btTroco = document.querySelector("#btTroco")
let h3Resultado = document.querySelector("#h3Resultado")

function subtrairValor(){

    let num1 = Number (inputNum1.value)
    let num2 = Number (inputNum2.value)

    h3Resultado.textContent = (num1 - num2)

}

btTroco.onclick = function(){
    subtrairValor();
}