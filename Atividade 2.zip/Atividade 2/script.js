let inputValorkg = document.querySelector("#inputValorkg");
let inputQuantidadekg = document.querySelector("#inputQuantidadekg");
let inputValorpago = document.querySelector("#inputValorpago")

function valorprodutoXkgproduto(){

    let kg = (inputValorkg.value)
    let quantidade = (inputQuantidadekg.value)

    inputValorpago.textContent = (kg * quantidade)
}

btCalcular.onclick = function(){
    valorprodutoXkgproduto();
}