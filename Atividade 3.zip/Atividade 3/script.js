let inputSaldo = document.querySelector("#inputSaldo");
let btImprimir = document.querySelector("#btImprimir");
let inputSaldoreajust = document.querySelector('#inputSaldoreajust');

function valorcomreajuste(){
    
    let saldototal = (Number(inputSaldo.value) * (1/100)) + Number(inputSaldo.value);

    inputSaldoreajust.textContent = (saldototal) 

}

btImprimir.onclick = function(){
    valorcomreajuste();
}