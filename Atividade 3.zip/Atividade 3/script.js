let inputSaldo = document.querySelector("#inputSaldo")
let btImprimir = document.querySelector("#btImprimir")
let inputSaldoreajust = document.querySelector('#inputSaldoreajust')

function valorcomreajuste(){
    let saldo = (inputSaldo.value)

    inputSaldoreajust = (saldo * 1/100) + ()
}

btImprimir.onclick = function(){
    valorcomreajuste();
}