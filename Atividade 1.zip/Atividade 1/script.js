let campoTexto1 = document.querySelector("#campoTexto1");
let campoTexto2 = document.querySelector("#campoTexto2");
let btSoma = document.querySelector("#btSoma");
let resultado = document.querySelector("#resultado");

function somarNumeros(){
    
    let num1 = Number (campoTexto1.value)
    let num2 = Number (campoTexto2.value)

    resultado.textContent = (num1 + num2)
} 

btSoma.onclick = function(){
    somarNumeros();
}